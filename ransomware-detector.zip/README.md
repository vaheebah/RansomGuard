# RansomGuard — Real-Time Ransomware Detection Using ML

> Behavioral ransomware detection using Machine Learning

## Features
- **Real-time folder monitoring** using Watchdog
- **3 ML models** compared: Decision Tree, Random Forest, SVM
- **React dashboard** with live logs, alerts, and analytics charts
- **Safe simulation script** to demo ransomware behavior without real malware
- **REST API** (Flask) connecting frontend to ML engine

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Tailwind CSS, Recharts |
| Backend | Flask, Flask-CORS |
| ML | Scikit-learn (Random Forest main model) |
| Monitoring | Watchdog |
| Charts | Recharts (AreaChart, BarChart, RadarChart, PieChart) |

